"use strict";
(() => {
  // src/content/dom-events.ts
  function setControlledValue(element, value) {
    const previousValue = element.value;
    element.focus();
    element.select();
    const command = element.ownerDocument.execCommand;
    if (typeof command === "function" && command.call(element.ownerDocument, "insertText", false, value) && element.value === value) {
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.blur();
      return;
    }
    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter) throw new Error("\u65E0\u6CD5\u8BBE\u7F6E OA \u63A7\u4EF6\u7684\u503C\u3002");
    setter.call(element, value);
    const tracked = element;
    tracked._valueTracker?.setValue(previousValue);
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: value }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.blur();
  }

  // src/content/oa-field-api.ts
  var REQUEST_SOURCE = "jg-reimburse-oa-autofill";
  var RESPONSE_SOURCE = "jg-reimburse-oa-autofill-result";
  function fieldValueMatches(actual, expected) {
    if (actual === expected) return true;
    if (!actual.trim() || !expected.trim()) return false;
    const actualNumber = Number(actual.replace(/,/g, ""));
    const expectedNumber = Number(expected.replace(/,/g, ""));
    return Number.isFinite(actualNumber) && Number.isFinite(expectedNumber) && Math.abs(actualNumber - expectedNumber) <= 1e-6;
  }
  function findField(doc, id) {
    const field = doc.getElementById(id);
    if (!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement)) {
      throw new Error(`\u672A\u627E\u5230 OA \u5B57\u6BB5 ${id}\u3002`);
    }
    return field;
  }
  async function waitForValue(field, value) {
    const deadline = Date.now() + 2e3;
    while (Date.now() < deadline) {
      if (fieldValueMatches(field.value, value)) return;
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    throw new Error(`OA \u5B57\u6BB5 ${field.id} \u672A\u4FDD\u7559\u2018${value}\u2019\u3002`);
  }
  async function setOaFieldValue(doc, id, value) {
    const field = findField(doc, id);
    if (typeof chrome === "undefined" || !chrome.runtime?.id) {
      setControlledValue(field, value);
      await waitForValue(field, value);
      return;
    }
    const win = doc.defaultView;
    if (!win) throw new Error("\u5F53\u524D OA \u9875\u9762\u4E0D\u53EF\u5199\u5165\u3002");
    const requestId = crypto.randomUUID();
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        win.removeEventListener("message", receive);
        reject(new Error("OA \u5B57\u6BB5\u63A5\u53E3\u54CD\u5E94\u8D85\u65F6\u3002"));
      }, 2e3);
      const receive = (event) => {
        if (event.source !== win || event.data?.source !== RESPONSE_SOURCE || event.data?.requestId !== requestId) return;
        clearTimeout(timeout);
        win.removeEventListener("message", receive);
        if (event.data.ok) resolve();
        else reject(new Error(event.data.error || "OA \u5B57\u6BB5\u63A5\u53E3\u5199\u5165\u5931\u8D25\u3002"));
      };
      win.addEventListener("message", receive);
      win.postMessage({ source: REQUEST_SOURCE, requestId, fieldId: id, value }, "*");
    });
    await waitForValue(field, value);
  }

  // src/content/page-contract.ts
  var OA_FIELDS = {
    title: "requestname",
    requestNumber: "field9766",
    applicant: "field9768",
    fillDate: "field9767",
    area: "field9770",
    department: "field9769",
    kind: "field9772",
    region: "field9771",
    category: "field9773",
    contract: "field10236",
    reason: "field9778",
    travelDays: "field10238",
    workDays: "field10239",
    expenseTotal: "field9779",
    taxTotal: "field9780",
    reimbursementTotal: "field9781",
    travelRequest: "field13685",
    paymentDate: "field9782"
  };
  var OA_TABLES = {
    trips: "oTable0",
    expenses: "oTable1"
  };
  function pageText(doc) {
    return doc.body?.textContent?.replace(/\s+/g, " ").trim() ?? "";
  }
  function fieldValue(doc, id) {
    const field = doc.getElementById(id);
    if (field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement || field instanceof HTMLSelectElement) {
      return field.value.trim();
    }
    return field?.textContent?.trim() ?? "";
  }
  function valueBesideLabel(doc, label) {
    for (const row of Array.from(doc.querySelectorAll("tr"))) {
      const cells = Array.from(row.querySelectorAll(":scope > th, :scope > td"));
      const labelIndex = cells.findIndex((cell) => cell.textContent?.trim() === label);
      if (labelIndex >= 0) {
        return cells[labelIndex + 1]?.textContent?.trim() ?? "";
      }
    }
    return "";
  }
  function tableHasData(table) {
    if (!table) return false;
    return Array.from(table.querySelectorAll("tr")).some((row) => {
      if (row.textContent?.includes("\u5408\u8BA1")) return false;
      return Array.from(row.querySelectorAll("input, textarea, select")).some((control) => {
        if (control instanceof HTMLInputElement) {
          if (["hidden", "button", "submit", "reset", "checkbox", "radio"].includes(control.type)) return false;
          return control.value.trim() !== "";
        }
        if (control instanceof HTMLTextAreaElement || control instanceof HTMLSelectElement) {
          return control.value.trim() !== "";
        }
        return false;
      });
    });
  }
  function detectKind(doc) {
    const value = valueBesideLabel(doc, "\u62A5\u9500\u7C7B\u578B") || fieldValue(doc, OA_FIELDS.kind);
    if (value.includes("\u5DEE\u65C5")) return "travel";
    if (value.includes("\u901A\u7528") || value.includes("\u5176\u4ED6")) return "general";
    return void 0;
  }
  function inspectPage(doc) {
    const text = pageText(doc);
    const requestNumber = valueBesideLabel(doc, "\u62A5\u9500\u5355\u53F7");
    const expenseTable = doc.getElementById(OA_TABLES.expenses);
    const tripTable = doc.getElementById(OA_TABLES.trips);
    const supported = text.includes("\u6280\u672F\u62A5\u9500") && text.includes("\u62A5\u9500\u5355\u53F7") && Boolean(requestNumber) && Boolean(doc.getElementById(OA_FIELDS.title) || doc.getElementById(OA_FIELDS.requestNumber)) && Boolean(expenseTable);
    const labels = {
      title: "\u6807\u9898",
      requestNumber: "\u62A5\u9500\u5355\u53F7",
      applicant: "\u7533\u8BF7\u4EBA",
      fillDate: "\u586B\u62A5\u65E5\u671F",
      area: "\u8D39\u7528\u5927\u533A",
      department: "\u8D39\u7528\u90E8\u95E8",
      kind: "\u62A5\u9500\u7C7B\u578B",
      region: "\u8D39\u7528\u5730\u533A",
      category: "\u62A5\u9500\u5206\u7C7B",
      contract: "\u9500\u552E\u5408\u540C",
      reason: "\u62A5\u9500\u4E8B\u7531",
      travelDays: "\u51FA\u5DEE\u5929\u6570",
      workDays: "\u5B9E\u9645\u5DE5\u4F5C\u5929\u6570",
      expenseTotal: "\u8D39\u7528\u5408\u8BA1",
      taxTotal: "\u589E\u503C\u7A0E\u4E13\u7968\u7A0E\u989D\u5408\u8BA1",
      reimbursementTotal: "\u62A5\u9500\u603B\u91D1\u989D",
      travelRequest: "\u51FA\u5DEE\u7533\u8BF7\u8BB0\u5F55",
      paymentDate: "\u62A5\u9500\u4ED8\u6B3E\u65E5\u671F"
    };
    const readonlyFields = Object.fromEntries(Object.entries(OA_FIELDS).map(([name, id]) => {
      const label = labels[name];
      return [name, label ? valueBesideLabel(doc, label) : fieldValue(doc, id)];
    }));
    if (!supported) {
      return {
        supported: false,
        reason: "\u8BF7\u5728\u5DF2\u751F\u6210\u62A5\u9500\u5355\u53F7\u7684\u2018\u5904\u7406 - \u6280\u672F\u62A5\u9500\u2019\u9875\u9762\u8FD0\u884C\u3002",
        readonlyFields,
        tripHasData: false,
        expenseHasData: false
      };
    }
    const kind = detectKind(doc);
    return {
      supported: Boolean(kind),
      reason: kind ? void 0 : "\u65E0\u6CD5\u8BC6\u522B\u9875\u9762\u4E2D\u7684\u62A5\u9500\u7C7B\u578B\u3002",
      kind,
      requestNumber,
      readonlyFields,
      tripHasData: tableHasData(tripTable),
      expenseHasData: tableHasData(expenseTable)
    };
  }

  // src/content/search-dialog.ts
  var SearchSelectionError = class extends Error {
    constructor(message) {
      super(message);
      this.name = "SearchSelectionError";
    }
  };
  function isVisible(element) {
    return !element.hasAttribute("hidden") && element.getAttribute("aria-hidden") !== "true";
  }
  function findDialog(doc, title) {
    return Array.from(doc.querySelectorAll('[role="dialog"]')).filter(isVisible).find((dialog) => Array.from(dialog.querySelectorAll("h1, h2, h3, [class*='title']")).some((heading) => heading.textContent?.trim() === title));
  }
  function waitForDialog(doc, title, timeoutMs = 5e3) {
    const current = findDialog(doc, title);
    if (current) return Promise.resolve(current);
    return new Promise((resolve, reject) => {
      const observer = new MutationObserver(() => {
        const dialog = findDialog(doc, title);
        if (!dialog) return;
        clearTimeout(timeout);
        observer.disconnect();
        resolve(dialog);
      });
      const timeout = setTimeout(() => {
        observer.disconnect();
        reject(new SearchSelectionError(`\u7B49\u5F85\u641C\u7D22\u7A97\u53E3\u2018${title}\u2019\u8D85\u65F6\u3002`));
      }, timeoutMs);
      observer.observe(doc.body, { childList: true, subtree: true });
    });
  }
  function exactRows(dialog, value) {
    return Array.from(dialog.querySelectorAll("tr")).filter(
      (row) => Array.from(row.querySelectorAll("td")).some((cell) => cell.textContent?.trim() === value)
    );
  }
  function waitForResultRows(dialog, value, timeoutMs = 5e3) {
    const inspect = () => ({
      all: dialog.querySelectorAll("tbody tr").length,
      exact: exactRows(dialog, value)
    });
    const current = inspect();
    if (current.all > 0) return Promise.resolve(current.exact);
    return new Promise((resolve, reject) => {
      const observer = new MutationObserver(() => {
        const result = inspect();
        if (result.all === 0) return;
        clearTimeout(timeout);
        observer.disconnect();
        resolve(result.exact);
      });
      const timeout = setTimeout(() => {
        observer.disconnect();
        reject(new SearchSelectionError(`\u7B49\u5F85\u641C\u7D22\u503C\u2018${value}\u2019\u7684\u7ED3\u679C\u8D85\u65F6\u3002`));
      }, timeoutMs);
      observer.observe(dialog, { childList: true, subtree: true });
    });
  }
  async function selectExactDialogValue(openButton, dialogTitle, value) {
    openButton.click();
    const dialog = await waitForDialog(openButton.ownerDocument, dialogTitle);
    const rows = await waitForResultRows(dialog, value);
    if (rows.length !== 1) {
      throw new SearchSelectionError(`\u641C\u7D22\u503C\u2018${value}\u2019\u7684\u7CBE\u786E\u7ED3\u679C\u6570\u4E3A ${rows.length}\uFF0C\u5DF2\u505C\u6B62\u586B\u5199\u3002`);
    }
    rows[0].click();
  }

  // src/content/detail-table.ts
  function dataRows(table) {
    return Array.from(table.querySelectorAll("tr")).filter(
      (row) => Boolean(row.querySelector('input[id^="field"], textarea[id^="field"]'))
    );
  }
  function rowHasData(row) {
    return Array.from(row.querySelectorAll("input, textarea")).some((control) => {
      if (!control.value.trim()) return false;
      if (control.type === "hidden") return /^field(?:9747|9748|9750|9751|9758)_\d+$/.test(control.id);
      return !["checkbox", "radio", "button"].includes(control.type);
    });
  }
  function findAction(table, label) {
    let scope = table.parentElement;
    while (scope) {
      const action = Array.from(scope.querySelectorAll("button, a, [role='button'], img, [title]")).find((element) => element.textContent?.trim() === label || element.getAttribute("title")?.trim() === label || element.getAttribute("aria-label")?.trim() === label || element.getAttribute("alt")?.trim() === label);
      if (action) return action;
      scope = scope.parentElement;
    }
    throw new Error(`\u672A\u627E\u5230\u660E\u7EC6\u8868\u7684\u2018${label}\u2019\u63A7\u4EF6\u3002`);
  }
  async function waitForRowCount(table, previous, shouldIncrease) {
    const deadline = Date.now() + 5e3;
    while (Date.now() < deadline) {
      const current = dataRows(table).length;
      if (shouldIncrease ? current > previous : current < previous || previous > 0 && current === 1 && !rowHasData(dataRows(table)[0])) return;
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    throw new Error("\u7B49\u5F85 OA \u660E\u7EC6\u884C\u53D8\u5316\u8D85\u65F6\u3002");
  }
  async function clearRows(table) {
    const rows = dataRows(table);
    if (!rows.some(rowHasData)) return;
    for (const row of rows) {
      const checkbox = row.querySelector('input[type="checkbox"]');
      if (checkbox) checkbox.click();
    }
    const before = rows.length;
    findAction(table, "\u5220\u9664").click();
    await waitForRowCount(table, before, false);
  }
  async function acquireRows(table, count, reusableIndexes = /* @__PURE__ */ new Set()) {
    const result = dataRows(table).filter((row) => reusableIndexes.has(rowIndex(row))).slice(0, count);
    const initialBlank = dataRows(table).find((row) => !rowHasData(row));
    if (initialBlank && !result.includes(initialBlank) && !dataRows(table).some(rowHasData) && count > 0) {
      result.push(initialBlank);
    }
    while (result.length < count) {
      const before = dataRows(table).length;
      findAction(table, "\u6DFB\u52A0").click();
      await waitForRowCount(table, before, true);
      const rows = dataRows(table);
      const added = rows.find((row) => !result.includes(row) && !rowHasData(row));
      if (!added) throw new Error("OA \u6DFB\u52A0\u660E\u7EC6\u884C\u540E\u672A\u627E\u5230\u65B0\u884C\u3002");
      result.push(added);
    }
    return result;
  }
  function rowIndex(row) {
    const index = Array.from(row.querySelectorAll('[id^="field"][id*="_"]')).map((field) => field.id.match(/_(\d+)$/)?.[1]).find((value) => value !== void 0);
    if (!index) throw new Error("OA \u660E\u7EC6\u884C\u7F3A\u5C11\u7A33\u5B9A\u884C\u53F7\u3002");
    return index;
  }
  function tripRowIndexes(doc) {
    const table = doc.getElementById(OA_TABLES.trips);
    if (!table) return /* @__PURE__ */ new Set();
    return new Set(dataRows(table).filter(rowHasData).map(rowIndex));
  }
  async function waitForLinkedTripRows(doc, before) {
    const table = doc.getElementById(OA_TABLES.trips);
    if (!table) throw new Error("\u5F53\u524D OA \u9875\u9762\u6CA1\u6709\u884C\u7A0B\u660E\u7EC6\u8868\u3002");
    const deadline = Date.now() + 3e3;
    while (Date.now() < deadline) {
      const indexes = dataRows(table).filter((row) => rowHasData(row) && !before.has(rowIndex(row))).map(rowIndex);
      if (indexes.length) return new Set(indexes);
      await new Promise((resolve) => setTimeout(resolve, 25));
    }
    throw new Error("\u9009\u62E9\u51FA\u5DEE\u7533\u8BF7\u540E\u672A\u751F\u6210\u884C\u7A0B\u660E\u7EC6\u3002");
  }
  async function setField(doc, id, value) {
    await setOaFieldValue(doc, id, value);
  }
  function verifyField(doc, id, value) {
    const field = doc.getElementById(id);
    if (!(field instanceof HTMLInputElement || field instanceof HTMLTextAreaElement) || !fieldValueMatches(field.value, value)) {
      throw new Error(`OA \u5B57\u6BB5 ${id} \u672A\u4FDD\u7559\u2018${value}\u2019\u3002`);
    }
  }
  async function waitForVisiblePanel(doc, panelSelector) {
    const find = () => Array.from(doc.querySelectorAll(panelSelector)).filter((panel) => !panel.hasAttribute("hidden") && panel.getAttribute("aria-hidden") !== "true").at(-1);
    const current = find();
    if (current) return current;
    return new Promise((resolve, reject) => {
      const observer = new MutationObserver(() => {
        const panel = find();
        if (!panel) return;
        clearTimeout(timeout);
        observer.disconnect();
        resolve(panel);
      });
      const timeout = setTimeout(() => {
        observer.disconnect();
        reject(new Error("OA \u65E5\u671F\u6216\u65F6\u95F4\u9009\u62E9\u5668\u672A\u6253\u5F00\u3002"));
      }, 5e3);
      observer.observe(doc.body, { childList: true, subtree: true });
    });
  }
  async function selectPickerValue(doc, fieldId, kind, value) {
    const deadline = Date.now() + 2e3;
    let field = null;
    let openButton = null;
    while (Date.now() < deadline) {
      const candidate = doc.getElementById(fieldId);
      if (candidate?.tagName === "INPUT") {
        field = candidate;
        openButton = field.parentElement?.querySelector(".picker-icon") ?? null;
        if (openButton) break;
      }
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    if (!field || !openButton) throw new Error(`\u672A\u627E\u5230 OA \u9009\u62E9\u5668 ${fieldId}\u3002`);
    openButton.click();
    const panel = await waitForVisiblePanel(doc, kind === "date" ? ".ant-calendar-picker-container" : ".ant-time-picker-panel");
    if (kind === "date") {
      const [year, month, date] = value.split("-");
      const title = `${Number(year)}-${Number(month)}-${Number(date)}`;
      const day = Array.from(panel.querySelectorAll("td[title]")).find((cell) => cell.getAttribute("title") === title);
      if (!day) throw new Error(`OA \u65E5\u5386\u4E2D\u672A\u627E\u5230\u2018${value}\u2019\u3002`);
      day.click();
    } else {
      const [hour, minute] = value.split(":");
      const hourOption = Array.from(panel.querySelectorAll(".ant-time-picker-panel-select li")).find((option) => option.textContent?.trim() === hour);
      const minuteOption = Array.from(panel.querySelectorAll(".wea-time-panel-item")).find((option) => option.textContent?.trim() === minute);
      if (!hourOption || !minuteOption) throw new Error(`OA \u65F6\u95F4\u9009\u62E9\u5668\u4E2D\u672A\u627E\u5230\u2018${value}\u2019\u3002`);
      hourOption.click();
      minuteOption.click();
    }
    const valueDeadline = Date.now() + 2e3;
    while (Date.now() < valueDeadline) {
      if (field.value === value) return;
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
    throw new Error(`OA \u9009\u62E9\u5668 ${fieldId} \u672A\u5199\u5165\u2018${value}\u2019\u3002`);
  }
  async function prepare(table, count, mode, reusableIndexes = /* @__PURE__ */ new Set()) {
    if (mode === "cancel" || count === 0) return [];
    if (mode === "overwrite") await clearRows(table);
    return acquireRows(table, count, reusableIndexes);
  }
  async function applyTrips(doc, rows, mode, reusableIndexes = /* @__PURE__ */ new Set()) {
    if (mode === "cancel" || rows.length === 0) return;
    const table = doc.getElementById(OA_TABLES.trips);
    if (!table) throw new Error("\u5F53\u524D OA \u9875\u9762\u6CA1\u6709\u884C\u7A0B\u660E\u7EC6\u8868\u3002");
    const targetRows = await prepare(table, rows.length, mode, reusableIndexes);
    const indexes = targetRows.map(rowIndex);
    for (const [position, trip] of rows.entries()) {
      const index = indexes[position];
      await selectPickerValue(doc, `field9747_${index}`, "date", trip.departureDate);
      await selectPickerValue(doc, `field9748_${index}`, "time", trip.departureTime);
      await selectPickerValue(doc, `field9750_${index}`, "date", trip.arrivalDate);
      await selectPickerValue(doc, `field9751_${index}`, "time", trip.arrivalTime);
    }
    for (const [position, trip] of rows.entries()) {
      const index = indexes[position];
      await setField(doc, `field9749_${index}`, trip.from);
      await setField(doc, `field9752_${index}`, trip.to);
      await setField(doc, `field9753_${index}`, String(trip.lodgingDays));
    }
    for (const [position, trip] of rows.entries()) {
      const index = indexes[position];
      verifyField(doc, `field9749_${index}`, trip.from);
      verifyField(doc, `field9752_${index}`, trip.to);
      verifyField(doc, `field9753_${index}`, String(trip.lodgingDays));
    }
  }
  async function applyExpenses(doc, kind, rows, mode) {
    if (mode === "cancel" || rows.length === 0) return;
    const table = doc.getElementById(OA_TABLES.expenses);
    if (!table) throw new Error("\u5F53\u524D OA \u9875\u9762\u6CA1\u6709\u62A5\u9500\u8D39\u7528\u660E\u7EC6\u8868\u3002");
    const targetRows = await prepare(table, rows.length, mode);
    const indexes = targetRows.map(rowIndex);
    for (const [position, expense] of rows.entries()) {
      const targetRow = targetRows[position];
      const index = indexes[position];
      const categoryField = doc.getElementById(`field9758_${index}`);
      const openButton = categoryField?.parentElement?.querySelector("button, a, [role='button'], img");
      if (!openButton) throw new Error(`\u8D39\u7528\u5206\u7C7B\u7B2C ${position + 1} \u884C\u6CA1\u6709\u641C\u7D22\u6309\u94AE\u3002`);
      await selectExactDialogValue(openButton, kind === "travel" ? "\u8D39\u7528\u5206\u7C7B\uFF08\u5DEE\u65C5\uFF09" : "\u8D39\u7528\u5206\u7C7B\uFF08\u901A\u7528\uFF09", expense.category);
    }
    for (const [position, expense] of rows.entries()) {
      const index = indexes[position];
      await setField(doc, `field9754_${index}`, kind === "travel" ? expense.tripRefs ?? "" : expense.incurredDate ?? "");
      await setField(doc, `field9755_${index}`, String(expense.reimbursementAmount));
      await setField(doc, `field9756_${index}`, String(expense.taxAmount));
      if (expense.note !== void 0) await setField(doc, `field9759_${index}`, expense.note);
    }
    for (const [position, expense] of rows.entries()) {
      const index = indexes[position];
      verifyField(doc, `field9754_${index}`, kind === "travel" ? expense.tripRefs ?? "" : expense.incurredDate ?? "");
      verifyField(doc, `field9755_${index}`, String(expense.reimbursementAmount));
      verifyField(doc, `field9756_${index}`, String(expense.taxAmount));
      if (expense.note !== void 0) verifyField(doc, `field9759_${index}`, expense.note);
    }
  }

  // src/content/travel-request.ts
  function dateKey(value) {
    const match = value.match(/(\d{4})\s*(?:-|\/|年)\s*(\d{1,2})\s*(?:-|\/|月)\s*(\d{1,2})\s*日?/);
    if (!match) return void 0;
    const key = Number(match[1]) * 1e4 + Number(match[2]) * 100 + Number(match[3]);
    return Number.isFinite(key) ? key : void 0;
  }
  function chooseNearestPriorCandidate(baseDate, candidates) {
    const base = dateKey(baseDate);
    if (!base) return { status: "missing" };
    const eligible = candidates.map((candidate) => ({ candidate, key: dateKey(candidate.date) })).filter((item) => item.key !== void 0 && item.key < base);
    if (!eligible.length) return { status: "missing" };
    const nearest = Math.max(...eligible.map((item) => item.key));
    const matches = eligible.filter((item) => item.key === nearest);
    return matches.length === 1 ? { status: "selected", candidate: matches[0].candidate } : { status: "ambiguous" };
  }
  function isTravelRequestRow(row) {
    const requestCode = row.querySelector("td")?.getAttribute("stsdata")?.trim() ?? "";
    const text = row.textContent?.trim() ?? "";
    return /^CCSQ\d+$/i.test(requestCode) && /\d{4}\s*(?:-|\/|年)\s*\d{1,2}\s*(?:-|\/|月)\s*\d{1,2}\s*日?/.test(text);
  }
  function candidateRows(doc) {
    return Array.from(doc.querySelectorAll("tr")).filter((row) => {
      return isTravelRequestRow(row) && row.getClientRects().length > 0;
    });
  }
  async function waitForRows(doc) {
    const deadline = Date.now() + 5e3;
    while (Date.now() < deadline) {
      const rows = candidateRows(doc);
      if (rows.length) return rows;
      await new Promise((resolve) => setTimeout(resolve, 25));
    }
    throw new Error("\u7B49\u5F85\u51FA\u5DEE\u7533\u8BF7\u8BB0\u5F55\u5019\u9009\u9879\u8D85\u65F6\u3002");
  }
  async function selectTravelRequest(doc, departureDate) {
    const span = doc.getElementById("field13685span");
    const button = span?.querySelector("button");
    if (!button) throw new Error("\u672A\u627E\u5230\u51FA\u5DEE\u7533\u8BF7\u8BB0\u5F55\u641C\u7D22\u6309\u94AE\u3002");
    button.click();
    const rows = await waitForRows(doc);
    const candidates = rows.flatMap((row) => {
      const text = row.textContent?.trim() ?? "";
      const match = text.match(/\d{4}\s*(?:-|\/|年)\s*\d{1,2}\s*(?:-|\/|月)\s*\d{1,2}\s*日?/);
      return match ? [{ row, date: match[0] }] : [];
    });
    const choice = chooseNearestPriorCandidate(departureDate, candidates);
    if (choice.status === "selected") {
      const cell = choice.candidate.row.querySelector("td");
      if (!cell) throw new Error("\u51FA\u5DEE\u7533\u8BF7\u8BB0\u5F55\u5019\u9009\u884C\u7F3A\u5C11\u9009\u62E9\u5355\u5143\u683C\u3002");
      cell.click();
      cell.click();
      cell.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: doc.defaultView }));
      const field = doc.getElementById("field13685");
      const deadline = Date.now() + 2e3;
      while (Date.now() < deadline) {
        if (field instanceof HTMLInputElement && field.value) {
          return {
            status: "selected",
            label: choice.candidate.row.querySelector("td")?.getAttribute("stsdata")?.trim(),
            applicationDate: choice.candidate.date.replace(/年|月/g, "-").replace(/日/g, "").replace(/\//g, "-")
          };
        }
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      throw new Error("\u51FA\u5DEE\u7533\u8BF7\u8BB0\u5F55\u70B9\u51FB\u540E\u672A\u5199\u5165 OA\u3002");
    }
    const cancel = Array.from(doc.querySelectorAll("button, a")).filter((item) => item.getClientRects().length > 0).find((item) => item.textContent?.replace(/\s/g, "") === "\u53D6\u6D88");
    cancel?.click();
    return choice;
  }

  // src/content/oa-adapter.ts
  var READONLY_FIELDS = [
    ["applicant", "applicant"],
    ["area", "area"],
    ["department", "department"],
    ["kind", "kind"],
    ["region", "region"],
    ["category", "category"],
    ["contract", "contract"]
  ];
  var EDITABLE_FIELDS = [
    ["travelDays", "travelDays"],
    ["workDays", "workDays"],
    ["paymentDate", "paymentDate"]
  ];
  function displayValue(key, value) {
    if (key === "kind") return value === "travel" ? "\u5DEE\u65C5" : "\u901A\u7528";
    return value === void 0 || value === null ? "" : String(value).trim();
  }
  function fail(fields, field, message, excel = []) {
    fields.push({ field, status: "error", message });
    return { ok: false, fields, totals: { excel, oa: [], match: false } };
  }
  function readNumber(doc, id) {
    const element = doc.getElementById(id);
    const raw = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : element?.textContent ?? "";
    return Number(raw.replace(/,/g, "").trim());
  }
  function moneyMatches(left, right) {
    return left.length === right.length && left.every(
      (value, index) => Number.isFinite(right[index]) && Math.abs(value - right[index]) <= 0.01
    );
  }
  async function waitForTotals(doc) {
    const read = () => [
      readNumber(doc, OA_FIELDS.expenseTotal),
      readNumber(doc, OA_FIELDS.taxTotal),
      readNumber(doc, OA_FIELDS.reimbursementTotal)
    ];
    const deadline = Date.now() + 5e3;
    let previous = read();
    let stableSince = Date.now();
    while (Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 50));
      const current = read();
      if (current.every((value, index) => value === previous[index])) {
        if (Date.now() - stableSince >= 300) return current;
      } else {
        previous = current;
        stableSince = Date.now();
      }
    }
    return previous;
  }
  async function fillReimbursementPage(doc, workbook, modes) {
    const fields = [];
    const excelTotals = [workbook.header.expenseTotal, workbook.header.taxTotal, workbook.header.reimbursementTotal];
    const inspection = inspectPage(doc);
    if (!inspection.supported) return fail(fields, "page", inspection.reason ?? "\u5F53\u524D\u9875\u9762\u4E0D\u652F\u6301\u586B\u5199\u3002", excelTotals);
    if (inspection.kind !== workbook.kind) {
      return fail(fields, "kind", "Excel \u62A5\u9500\u7C7B\u578B\u4E0E OA \u9875\u9762\u4E0D\u4E00\u81F4\u3002", excelTotals);
    }
    for (const [headerKey, fieldKey] of READONLY_FIELDS) {
      const expected = displayValue(headerKey, workbook.header[headerKey]);
      if (!expected) {
        fields.push({ field: fieldKey, status: "skipped" });
        continue;
      }
      const actual = inspection.readonlyFields[fieldKey]?.trim() ?? "";
      if (actual !== expected) {
        return fail(fields, fieldKey, `Excel \u4E3A\u2018${expected}\u2019\uFF0COA \u4E3A\u2018${actual}\u2019\u3002`, excelTotals);
      }
      fields.push({ field: fieldKey, status: "verified" });
    }
    try {
      if (workbook.kind === "travel") {
        let linkedTripRows = /* @__PURE__ */ new Set();
        if (workbook.trips[0]?.departureDate) {
          const before = tripRowIndexes(doc);
          const request = await selectTravelRequest(doc, workbook.trips[0].departureDate);
          if (request.status === "selected") {
            linkedTripRows = await waitForLinkedTripRows(doc, before);
            fields.push({
              field: "travelRequest",
              status: "filled",
              message: request.applicationDate
            });
          } else fields.push({
            field: "travelRequest",
            status: "skipped",
            message: request.status === "ambiguous" ? "\u6700\u8FD1\u65E5\u671F\u6709\u591A\u6761\u8BB0\u5F55\uFF0C\u8BF7\u624B\u52A8\u9009\u62E9\u3002" : "\u6CA1\u6709\u627E\u5230\u51FA\u53D1\u65E5\u524D\u7684\u8BB0\u5F55\uFF0C\u8BF7\u624B\u52A8\u9009\u62E9\u3002"
          });
        }
        await applyTrips(doc, workbook.trips, modes.trips, linkedTripRows);
        fields.push({ field: "trips", status: modes.trips === "cancel" ? "skipped" : "filled" });
      }
      await applyExpenses(doc, workbook.kind, workbook.expenses, modes.expenses);
      fields.push({ field: "expenses", status: modes.expenses === "cancel" ? "skipped" : "filled" });
    } catch (error) {
      return fail(
        fields,
        workbook.kind === "travel" && !fields.some((item) => item.field === "trips") ? "trips" : "expenses",
        error instanceof Error ? error.message : String(error),
        excelTotals
      );
    }
    for (const [headerKey, fieldKey] of EDITABLE_FIELDS) {
      const value = displayValue(headerKey, workbook.header[headerKey]);
      if (!value) {
        fields.push({ field: fieldKey, status: "skipped" });
        continue;
      }
      const element = doc.getElementById(OA_FIELDS[fieldKey]);
      if (!(element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement)) {
        return fail(fields, fieldKey, `\u672A\u627E\u5230\u53EF\u586B\u5199\u7684 OA \u5B57\u6BB5 ${OA_FIELDS[fieldKey]}\u3002`, excelTotals);
      }
      if (element instanceof HTMLInputElement && element.type === "hidden") {
        fields.push({ field: fieldKey, status: "skipped", message: "\u5F53\u524D OA \u9875\u9762\u4E0D\u5141\u8BB8\u7F16\u8F91\u8BE5\u5B57\u6BB5\u3002" });
        continue;
      }
      try {
        await setOaFieldValue(doc, OA_FIELDS[fieldKey], value);
        if (!fieldValueMatches(element.value, value)) {
          throw new Error(`OA \u5B57\u6BB5 ${OA_FIELDS[fieldKey]} \u672A\u4FDD\u7559\u2018${value}\u2019\u3002`);
        }
        fields.push({ field: fieldKey, status: "filled" });
      } catch (error) {
        return fail(fields, fieldKey, error instanceof Error ? error.message : String(error), excelTotals);
      }
    }
    const oaTotals = await waitForTotals(doc);
    const match = moneyMatches(excelTotals, oaTotals);
    if (!match) fields.push({ field: "totals", status: "error", message: "Excel \u4E0E OA \u5408\u8BA1\u4E0D\u4E00\u81F4\u3002" });
    return { ok: match, fields, totals: { excel: excelTotals, oa: oaTotals, match } };
  }

  // src/content/index.ts
  async function handleExtensionMessage(message, doc = document) {
    if (message.type === "INSPECT_PAGE") return inspectPage(doc);
    if (message.type === "FILL_PAGE") return fillReimbursementPage(doc, message.workbook, message.modes);
    throw new Error("\u4E0D\u652F\u6301\u7684\u63D2\u4EF6\u6D88\u606F\u3002");
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      handleExtensionMessage(message).then(sendResponse).catch((error) => sendResponse({
        ok: false,
        error: {
          name: error instanceof Error ? error.name : "Error",
          message: error instanceof Error ? error.message : String(error)
        }
      }));
      return true;
    });
  }
  document.documentElement.dataset.reimburseAutofill = "ready";
})();
