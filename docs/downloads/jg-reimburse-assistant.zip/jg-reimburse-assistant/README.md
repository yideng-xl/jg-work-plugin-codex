# JG报销助理（JG Reimburse Assistant）

报销处理专家：上海巨耕报销自动化。扫描电子发票，自动生成报销摘要、OA 差旅报销明细、交通费明细与 A4 发票拼贴。

## 类型

Agent 型（单个 AI 专家）

## 功能

- 扫描报销素材文件夹中的电子发票（高铁票、打车行程单、酒店住宿专票、水单等）
- 阶段一：生成可编辑的报销摘要 Excel（`05-需确认-报销摘要.xlsx`），供人工核对确认
- 阶段二：根据确认后的摘要，生成 OA 差旅报销明细、交通费明细、A4 发票拼贴 PDF（`09-终稿-*`）
- 内置金额口径核算（价税合计、专票税额、补贴、差旅天数自动计算）

## 版本机制（重要）

本专家**不内置报销 skill 副本**，每次执行时自动从公司 GitHub 仓库同步最新版：

- 仓库：`https://github.com/yideng-xl/jg-work-plugin-codex`
- skill 路径：`plugins/jg-work-plugin-codex/skills/reimburse/`
- 每次执行第一步自动 `git clone` 最新版到临时目录并安装依赖

**收益：skill 更新后无需重新安装本专家**，同事每次使用时自动用上最新版。

**前置要求**：使用本专家的电脑需要能访问 GitHub（git 已安装、网络可达）。若 clone 失败，专家会提示检查网络。

## 使用示例

- 「帮我扫描 /Users/xxx/报销素材 文件夹，生成报销摘要」
- 「摘要核对好了，生成终稿」
- 「把高铁票和打车票分开整理成明细」

## 安装

1. 打开 WorkBuddy，点击左侧「专家」进入专家中心
2. 导入本 zip 安装包（或在「我的专家」中导入专家包）
3. 重启 WorkBuddy，在「我的专家」中即可看到「JG报销助理」

手动安装方式：将本目录解压/放置到
`~/.workbuddy/plugins/marketplaces/my-experts/plugins/jg-reimburse-assistant/`
后重启 WorkBuddy。

## 更新

本专家的 skill 由 GitHub 自动同步，**无需因 skill 更新而重新安装专家**。
只有当专家本身的指令、头像等发生变化时才需要重新导入 zip。

## 头像

头像位于 `avatars/`，可替换：PNG（推荐）/ JPG，512×512 px，单张 ≤ 500KB。
