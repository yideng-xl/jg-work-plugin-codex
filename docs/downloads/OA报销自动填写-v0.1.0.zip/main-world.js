"use strict";
(() => {
  // src/main-world/index.ts
  var REQUEST_SOURCE = "jg-reimburse-oa-autofill";
  var RESPONSE_SOURCE = "jg-reimburse-oa-autofill-result";
  function installMainWorldBridge(win = window) {
    win.addEventListener("message", (event) => {
      if (event.source !== win || event.data?.source !== REQUEST_SOURCE) return;
      const { requestId, fieldId, value } = event.data;
      try {
        if (typeof win.WfForm?.changeFieldValue !== "function") throw new Error("OA \u5B57\u6BB5\u63A5\u53E3\u5C1A\u672A\u5C31\u7EEA\u3002");
        win.WfForm.changeFieldValue(fieldId, { value });
        win.postMessage({ source: RESPONSE_SOURCE, requestId, ok: true }, "*");
      } catch (error) {
        win.postMessage({
          source: RESPONSE_SOURCE,
          requestId,
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        }, "*");
      }
    });
  }
  installMainWorldBridge();
})();
